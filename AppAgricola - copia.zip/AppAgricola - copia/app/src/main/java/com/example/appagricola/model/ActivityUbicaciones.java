package com.example.appagricola.model;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.appagricola.R;
import com.example.appagricola.DataStorage.Clases;

import java.util.ArrayList;
import java.util.List;

public class ActivityUbicaciones extends AppCompatActivity {

    private Spinner spinnerUbicacionesExistentes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicaciones);

        // Inicializar el spinner de ubicaciones existentes
        spinnerUbicacionesExistentes = findViewById(R.id.spinnerUbicacionesExistentes);

        // Agregar ubicaciones de muestra si la lista está vacía
        if (Clases.ubicaciones.isEmpty()) {
            Clases.ubicaciones.add(new Clases.Ubicacion(1, "Invernadero", "Área principal de cultivo"));
            Clases.ubicaciones.add(new Clases.Ubicacion(2, "Campo Este", "Campo al este de la granja"));
            Clases.ubicaciones.add(new Clases.Ubicacion(3, "Almacén", "Espacio de almacenamiento"));
        }

        // Actualizar el spinner con las ubicaciones iniciales
        actualizarSpinnerUbicaciones();

        EditText editTextNombre = findViewById(R.id.editTextNombreUbicacion);
        EditText editTextDescripcion = findViewById(R.id.editTextDescripcionUbicacion);
        Button buttonGuardar = findViewById(R.id.buttonGuardarUbicacion);

        buttonGuardar.setOnClickListener(v -> {
            String nombre = editTextNombre.getText().toString().trim();
            String descripcion = editTextDescripcion.getText().toString().trim();

            // Validación del campo "nombre" (obligatorio y de 5 a 15 caracteres)
            if (nombre.isEmpty() || nombre.length() < 5 || nombre.length() > 15) {
                Toast.makeText(this, "El nombre es obligatorio y debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validación del campo "descripción" (opcional y máximo 30 caracteres)
            if (!descripcion.isEmpty() && descripcion.length() > 30) {
                Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show();
                return;
            }

            // Crear y guardar la ubicación
            Clases.Ubicacion ubicacion = new Clases.Ubicacion(
                    Clases.ubicaciones.size() + 1,
                    nombre,
                    descripcion
            );
            Clases.ubicaciones.add(ubicacion);

            // Actualizar el spinner después de guardar una nueva ubicación
            actualizarSpinnerUbicaciones();

            // Limpiar los campos después de guardar
            editTextNombre.getText().clear();
            editTextDescripcion.getText().clear();

            Toast.makeText(this, "Ubicación guardada correctamente", Toast.LENGTH_SHORT).show();
        });
    }

    // Método para llenar el Spinner con las ubicaciones actuales
    private void actualizarSpinnerUbicaciones() {
        List<String> nombresUbicaciones = new ArrayList<>();
        for (Clases.Ubicacion ubicacion : Clases.ubicaciones) {
            nombresUbicaciones.add(ubicacion.getNombre());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, nombresUbicaciones);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUbicacionesExistentes.setAdapter(adapter);
    }
}
