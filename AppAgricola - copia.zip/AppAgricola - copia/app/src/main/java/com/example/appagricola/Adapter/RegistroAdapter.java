package com.example.appagricola.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appagricola.R;
import com.example.appagricola.DataStorage.Clases;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

public class RegistroAdapter extends RecyclerView.Adapter<RegistroAdapter.RegistroViewHolder> {

    private final List<Clases.Sensor> sensores;

    // Constructor del adapter, recibe la lista de sensores
    public RegistroAdapter(List<Clases.Sensor> sensores) {
        this.sensores = sensores;
    }

    // Clase interna para el ViewHolder, aquí vamos a encontrar todos los TextView y demás
    public static class RegistroViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUbicacionNombre;
        TextView textViewUbicacion;
        TextView textViewDescripcionhubicacion;
        TextView textViewSensorNombretitulo;
        TextView textViewSensorNombre;
        TextView textViewTipo;
        TextView textViewDescripcion;
        TextView textViewIdeal;
        TextView textViewRegistro;
        TextView textViewLectura;
        TextView textViewFechaCreacion;

        // Constructor del ViewHolder, donde linkeamos los TextView con el layout
        public RegistroViewHolder(View view) {
            super(view);
            textViewUbicacionNombre = view.findViewById(R.id.textViewUbicacionNombre);
            textViewUbicacion = view.findViewById(R.id.textViewUbicacion);
            textViewDescripcionhubicacion = view.findViewById(R.id.textViewDescripcionhubicacion);
            textViewSensorNombretitulo = view.findViewById(R.id.textViewSensorNombretitulo);
            textViewSensorNombre = view.findViewById(R.id.textViewSensorNombre);
            textViewTipo = view.findViewById(R.id.textViewTipo);
            textViewDescripcion = view.findViewById(R.id.textViewDescripcion);
            textViewIdeal = view.findViewById(R.id.textViewIdeal);
            textViewRegistro = view.findViewById(R.id.textViewRegistro);
            textViewLectura = view.findViewById(R.id.textViewLectura);
            textViewFechaCreacion = view.findViewById(R.id.textViewFechaCreacion);
        }
    }

    @Override
    public RegistroViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflando el layout para cada item de la lista
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sensor, parent, false);
        return new RegistroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RegistroViewHolder holder, int position) {
        // Sacamos el sensor actual de la lista
        Clases.Sensor sensor = sensores.get(position);

        // Configurar campos de la interfaz
        holder.textViewUbicacionNombre.setText("Ubicación:");
        holder.textViewUbicacion.setText("Ubicación: " + sensor.getUbicacion().getNombre());
        String descripcionUbicacion = sensor.getUbicacion().getDescripcion();
        holder.textViewDescripcionhubicacion.setText("Descripción: " + (descripcionUbicacion.isEmpty() ? "No disponible" : descripcionUbicacion));
        holder.textViewSensorNombretitulo.setText("Sensor:");
        holder.textViewSensorNombre.setText("Sensor: " + sensor.getNombre());
        holder.textViewTipo.setText("Tipo: " + sensor.getTipo().getNombre());
        String descripcionSensor = sensor.getDescripcion();
        holder.textViewDescripcion.setText("Descripción: " + (descripcionSensor.isEmpty() ? "N/A" : descripcionSensor));
        holder.textViewIdeal.setText("Ideal: " + sensor.getIdeal());
        holder.textViewRegistro.setText("Registro: " + sensor.getRegistro());

        // Generar y establecer un valor aleatorio para la lectura entre 80% y 120% del valor ideal
        Random random = new Random();
        float min = sensor.getIdeal() * 0.8f;
        float max = sensor.getIdeal() * 1.2f;
        float lectura = min + random.nextFloat() * (max - min);
        holder.textViewLectura.setText("Lectura: " + String.format(Locale.getDefault(), "%.2f", lectura));

        // Formatear y mostrar la fecha de creación en formato chileno (dd/MM/yyyy HH:mm:ss)
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        dateFormat.setTimeZone(TimeZone.getTimeZone("America/Santiago"));
        holder.textViewFechaCreacion.setText("Fecha de Creación: " + dateFormat.format(sensor.getFechaCreacion()));
    }

    @Override
    public int getItemCount() {
        return sensores.size();
    }
}
