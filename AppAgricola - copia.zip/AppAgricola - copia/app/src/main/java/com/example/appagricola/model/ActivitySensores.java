package com.example.appagricola.model;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

import com.example.appagricola.DataStorage.Clases;
import com.example.appagricola.R;

public class ActivitySensores extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensores);

        Spinner spinnerUbicaciones = findViewById(R.id.spinnerUbicaciones);
        Spinner spinnerTipoSensor = findViewById(R.id.spinnerTipoSensor);
        EditText editTextNombre = findViewById(R.id.editTextNombreSensor);
        EditText editTextDescripcion = findViewById(R.id.editTextDescripcionSensor);
        EditText editTextIdeal = findViewById(R.id.editTextIdealSensor);
        Button buttonGuardar = findViewById(R.id.buttonGuardarSensor);

        // Configurar el spinner de ubicaciones
        List<String> ubicacionNombres = new ArrayList<>();
        for (Clases.Ubicacion ubicacion : Clases.ubicaciones) {
            ubicacionNombres.add(ubicacion.getNombre());
        }
        ArrayAdapter<String> adapterUbicaciones = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ubicacionNombres);
        adapterUbicaciones.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUbicaciones.setAdapter(adapterUbicaciones);

        // Configurar el spinner de tipo de sensor con "Temperatura" y "Humedad"
        List<String> tiposSensores = new ArrayList<>();
        tiposSensores.add("Temperatura");
        tiposSensores.add("Humedad");
        ArrayAdapter<String> adapterTipos = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tiposSensores);
        adapterTipos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipoSensor.setAdapter(adapterTipos);

        buttonGuardar.setOnClickListener(v -> {
            String nombre = editTextNombre.getText().toString().trim();
            String descripcion = editTextDescripcion.getText().toString().trim();
            String idealText = editTextIdeal.getText().toString().trim();

            // Validación del campo "ideal" para asegurar que sea positivo
            float ideal = 0f;
            if (idealText.isEmpty()) {
                Toast.makeText(this, "El campo ideal es obligatorio y debe ser un valor positivo", Toast.LENGTH_SHORT).show();
                return;
            } else {
                try {
                    ideal = Float.parseFloat(idealText);
                    if (ideal <= 0) {
                        Toast.makeText(this, "El campo ideal debe ser un valor positivo", Toast.LENGTH_SHORT).show();
                        return;
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "El campo ideal debe ser un número válido", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            // Validación del campo "nombre" (obligatorio y de 5 a 15 caracteres)
            if (nombre.isEmpty() || nombre.length() < 5 || nombre.length() > 15) {
                Toast.makeText(this, "El nombre es obligatorio y debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validación del campo "descripción" (opcional y máximo 30 caracteres)
            if (!descripcion.isEmpty() && descripcion.length() > 30) {
                Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show();
                return;
            }

            // Obtener la ubicación seleccionada
            Clases.Ubicacion ubicacionSeleccionada = Clases.ubicaciones.get(spinnerUbicaciones.getSelectedItemPosition());

            // Verificar si el nombre del sensor ya existe
            for (Clases.Sensor s : Clases.sensores) {
                if (s.getNombre().equalsIgnoreCase(nombre)) {
                    Toast.makeText(this, "El nombre de sensor ya existe", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            // Generar un nuevo ID y validar que no esté duplicado
            int nuevoId = Clases.sensores.size() + 1;
            if (Clases.validarIdSensor(nuevoId)) {
                Toast.makeText(this, "El ID de sensor ya existe", Toast.LENGTH_SHORT).show();
            } else {
                // Crear y guardar el sensor
                Clases.Sensor sensor = new Clases.Sensor(
                        nuevoId,
                        nombre,
                        descripcion,
                        ideal,
                        new Clases.Tipo(spinnerTipoSensor.getSelectedItemPosition() + 1, spinnerTipoSensor.getSelectedItem().toString()),
                        ubicacionSeleccionada
                );
                Clases.sensores.add(sensor);

                // Limpiar los campos después de guardar
                editTextNombre.getText().clear();
                editTextDescripcion.getText().clear();
                editTextIdeal.getText().clear();

                Toast.makeText(this, "Sensor guardado correctamente", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
