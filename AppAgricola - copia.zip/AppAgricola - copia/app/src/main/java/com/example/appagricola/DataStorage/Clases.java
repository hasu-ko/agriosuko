package com.example.appagricola.DataStorage;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class Clases {

    // Almacenamiento temporal de ubicaciones y sensores
    public static List<Ubicacion> ubicaciones = new ArrayList<>();
    public static List<Sensor> sensores = new ArrayList<>();

    public static boolean validarIdSensor(int nuevoId) {
        for (Sensor sensor : sensores) {
            if (sensor.getId() == nuevoId) {
                return true; // El ID ya existe
            }
        }
        return false; // El ID no existe
    }

    // Clase Ubicacion
    public static class Ubicacion {
        private int id;
        private String nombre;
        private String descripcion;

        public Ubicacion(int id, String nombre, String descripcion) {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
        }

        public int getId() { return id; }
        public String getNombre() { return nombre; }
        public String getDescripcion() { return descripcion; }
    }

    // Clase Tipo
    public static class Tipo {
        private int id;
        private String nombre;

        public Tipo(int id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }

        public int getId() { return id; }
        public String getNombre() { return nombre; }
    }

    // Clase Sensor
    public static class Sensor {
        private int id;
        private String nombre;
        private String descripcion;
        private float ideal;
        private Tipo tipo;
        private Ubicacion ubicacion;
        private Date fechaCreacion; // Fecha de creación del sensor
        private String registro;    // Registro asociado al sensor
        private List<Registro> registros = new ArrayList<>(); // Lista de registros del sensor

        public Sensor(int id, String nombre, String descripcion, float ideal, Tipo tipo, Ubicacion ubicacion) {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.ideal = ideal;
            this.tipo = tipo;
            this.ubicacion = ubicacion;
            this.fechaCreacion = new Date(); // Fecha de creación actual al momento de crear el sensor
            this.registro = ""; // Valor inicial para el registro
        }

        public int getId() { return id; }
        public String getNombre() { return nombre; }
        public String getDescripcion() { return descripcion; }
        public float getIdeal() { return ideal; }
        public Tipo getTipo() { return tipo; }
        public Ubicacion getUbicacion() { return ubicacion; }
        public Date getFechaCreacion() { return fechaCreacion; }
        public String getRegistro() { return registro; }

        // Método para obtener el último registro (el más reciente) de la lista
        public Registro obtenerUltimoRegistro() {
            if (registros.isEmpty()) {
                return null; // No hay registros
            }
            return registros.get(registros.size() - 1); // Retorna el último registro en la lista
        }

        // Método para añadir un nuevo registro con una lectura aleatoria basada en el valor ideal
        public void agregarRegistro() {
            int nuevoId = registros.size() + 1;
            Registro nuevoRegistro = new Registro(nuevoId, this);
            registros.add(nuevoRegistro);
        }
    }

    // Clase Registro
    public static class Registro {
        private int id;
        private Date instante;
        private float lectura;
        private Sensor sensor;

        // Constructor que genera un valor aleatorio de lectura basado en el valor ideal del sensor
        public Registro(int id, Sensor sensor) {
            this.id = id;
            this.sensor = sensor;
            this.instante = new Date(); // Fecha y hora actuales

            // Generar un valor aleatorio entre 80% y 120% del valor ideal
            Random random = new Random();
            float min = sensor.getIdeal() * 0.8f;
            float max = sensor.getIdeal() * 1.2f;
            this.lectura = min + random.nextFloat() * (max - min);
        }

        public int getId() { return id; }
        public Date getInstante() { return instante; }
        public float getLectura() { return lectura; }
        public Sensor getSensor() { return sensor; }
    }
}
