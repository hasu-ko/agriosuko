package com.example.appagricola.model;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.appagricola.DataStorage.Clases;
import com.example.appagricola.R;
import com.example.appagricola.Adapter.RegistroAdapter;

public class ActivityHistorial extends AppCompatActivity {

    private RecyclerView recyclerViewHistorial;
    private RegistroAdapter registroAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        // Agregar datos de ejemplo si la lista de sensores está vacía
        if (Clases.sensores.isEmpty()) {
            Clases.Ubicacion ubicacion1 = new Clases.Ubicacion(1, "Invernadero", "Área principal de cultivo");
            Clases.Ubicacion ubicacion2 = new Clases.Ubicacion(2, "Campo Este", "Zona de pruebas");
            Clases.Tipo tipoTemperatura = new Clases.Tipo(1, "Temperatura");
            Clases.Tipo tipoHumedad = new Clases.Tipo(2, "Humedad");

            // Agregar sensores de ejemplo con las ubicaciones y tipos creados
            Clases.sensores.add(new Clases.Sensor(1, "Sensor1", "Monitoreo de temperatura", 25.0f, tipoTemperatura, ubicacion1));
            Clases.sensores.add(new Clases.Sensor(2, "Sensor2", "Monitoreo de humedad", 60.0f, tipoHumedad, ubicacion2));
        }

        recyclerViewHistorial = findViewById(R.id.recyclerViewHistorial);
        recyclerViewHistorial.setLayoutManager(new LinearLayoutManager(this));

        // Configurar el adaptador con la lista de sensores y asignarlo al RecyclerView
        registroAdapter = new RegistroAdapter(Clases.sensores);
        recyclerViewHistorial.setAdapter(registroAdapter);

        // Configurar el botón de salida
        Button buttonSalir = findViewById(R.id.buttonSalir);
        buttonSalir.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityHistorial.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
